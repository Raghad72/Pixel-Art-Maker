


// call makeGrid() when zise inputs is submitted
var press = document.getElementById("gettingOutput");
press.addEventListener('click', function (event) {

    // prevent form from occuring during the submit
    event.preventDefault();
    var height = document.getElementById("inputHeight").value;
    var width = document.getElementById("inputWidth").value;
    
    makeGrid(height, width);
});



function makeGrid(height, width) {
    
    // clear old grid
    var Table = document.getElementById('pixelCanvas');
    Table.innerHTML = " ";

    // cycling through user size inputs + generating a grid
    for (let i = 0; i < height; i++) {
        var row = document.createElement('tr');

        for (let x = 0; x < width; x++) {
            var cell = document.createElement('td');
            row.appendChild(cell);

            // change background color of event target when clicked
            cell.addEventListener('click', function (e) {
                e.preventDefault();
                var pick = document.getElementById("colorPicker").value;
                e.target.style.backgroundColor = pick;
            });
        }
        Table.appendChild(row);
    }
}


